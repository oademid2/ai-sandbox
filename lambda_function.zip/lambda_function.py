import json
from research_sequence_task import ResearchSequenceTask

task = ResearchSequenceTask()

def lambda_handler(event, context):
    params = event.get("queryStringParameters") or {}
    print(event, context,"")

    action = params.get("action")
    if not action:
        return _response(400, {"error": "Missing required query parameter: action"})

    if action == "brainstorm":
        market_description = params.get("market_description")
        if not market_description:
            return _response(400, {"error": "Missing 'market_description' for brainstorm action"})
        formulas = task.generate_market_formulas(market_description)
        return _response(200, {"formulas": formulas})

    elif action == "decompose":
        formula = params.get("formula")
        if not formula:
            return _response(400, {"error": "Missing 'formula' for decompose action"})
        components = task.get_components_from_formula(formula)
        return _response(200, {"components": components})

    elif action == "datasource":
        formula = params.get("formula")
        if not formula:
            return _response(400, {"error": "Missing 'formula' for datasource action"})
        datasources = task.find_data_for_formula(formula)
        return _response(200, {"datasources": datasources})

    else:
        return _response(400, {"error": f"Unknown action: {action}"})

def _response(status_code, body_dict):
    """
    Utility to create an API Gateway-friendly response.
    """
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body_dict)
    }